package org.xmlcml.pdf2svg.xmllog.model;

import java.util.ArrayList;

public class PDFFontList extends ArrayList<PDFFont> {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "[pdf font list]";
	}

}
