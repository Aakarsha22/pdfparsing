package org.xmlcml.pdf2svg.xmllog.model;

import java.util.ArrayList;

public class PDFPageList extends ArrayList<PDFPage> {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "[pdf page list]";
	}

}
