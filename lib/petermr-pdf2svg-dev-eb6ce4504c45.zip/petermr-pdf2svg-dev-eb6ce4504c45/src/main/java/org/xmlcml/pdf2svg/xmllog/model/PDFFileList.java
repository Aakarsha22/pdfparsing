package org.xmlcml.pdf2svg.xmllog.model;

import java.util.ArrayList;

public class PDFFileList extends ArrayList<PDFFile> {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "[pdf file list]";
	}

}
