package org.xmlcml.pdf2svg.xmllog.model;

import java.util.ArrayList;

public class PDFCharList extends ArrayList<PDFChar> {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "[pdf char list]";
	}

}
