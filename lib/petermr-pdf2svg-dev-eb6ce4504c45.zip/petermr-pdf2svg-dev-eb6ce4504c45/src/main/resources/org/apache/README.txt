PDFBox 1.7.1. resources are copied as they are not alwayspicked up from the jars.
Do not delete