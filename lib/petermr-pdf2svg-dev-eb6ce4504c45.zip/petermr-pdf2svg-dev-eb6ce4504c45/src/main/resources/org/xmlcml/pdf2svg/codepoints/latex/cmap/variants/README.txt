foo-m.cmap seems to be functionally identical to foo.cmap
