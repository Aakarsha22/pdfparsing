package org.xmlcml.pdf2svg.codepoints;

public class Fixtures {
	public static final String CODEPOINTS_DIR = "org/xmlcml/pdf2svg/codepoints/";

}
